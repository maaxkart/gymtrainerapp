class FacilityModel {

  final int id;
  final String name;
  final String category;
  final List<String> questions;

  FacilityModel({
    required this.id,
    required this.name,
    required this.category,
    required this.questions,
  });

  factory FacilityModel.fromJson(Map<String, dynamic> json) {
    return FacilityModel(
      id: json['id'],
      name: json['name'],
      category: json['category'],
      questions: List<String>.from(json['questions']),
    );
  }
}