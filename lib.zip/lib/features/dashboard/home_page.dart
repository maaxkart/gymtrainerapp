import 'package:flutter/material.dart';
import 'package:shared_preferences/shared_preferences.dart';

import '../members/members_screen.dart';
import '../payments/payments_screen.dart';
import '../packages/packages_screen.dart';
import '../videos/videos_screen.dart';
import '../notifications/alert_screen.dart';

const gold = Color(0xffFFB300);
const bg = Color(0xff0B0D12);
const card = Color(0xff12141A);

class HomePage extends StatefulWidget {
  const HomePage({super.key});

  @override
  State<HomePage> createState() => _HomePageState();
}

class _HomePageState extends State<HomePage> {

  String name = "Trainer";
  String gym = "Gym";

  @override
  void initState() {
    super.initState();
    loadUser();
  }

  /// LOAD USER FROM SHARED PREF
  Future<void> loadUser() async {

    final prefs = await SharedPreferences.getInstance();

    setState(() {
      name = prefs.getString("name") ?? "Trainer";
      gym = prefs.getString("gym") ?? "Gym";
    });
  }

  @override
  Widget build(BuildContext context) {

    return Scaffold(
      backgroundColor: bg,

      body: CustomScrollView(
        slivers: [

          /// 🔥 PREMIUM APP BAR
          SliverAppBar(
            backgroundColor: bg,
            pinned: true,
            expandedHeight: 140,

            flexibleSpace: FlexibleSpaceBar(
              background: Padding(
                padding:
                const EdgeInsets.fromLTRB(20, 60, 20, 20),

                child: Row(
                  children: [

                    /// PROFILE
                    Container(
                      height: 50,
                      width: 50,
                      decoration: BoxDecoration(
                        color: card,
                        shape: BoxShape.circle,
                        border: Border.all(color: gold),
                      ),
                      child: const Icon(
                        Icons.person,
                        color: Colors.white70,
                      ),
                    ),

                    const SizedBox(width: 12),

                    /// USER INFO
                    Flexible(
                      child: Column(
                        mainAxisSize: MainAxisSize.min,   // 🔥 IMPORTANT
                        crossAxisAlignment: CrossAxisAlignment.start,
                        children: [

                          const Text(
                            "Welcome Back 👋",
                            style: TextStyle(
                              color: Colors.white54,
                              fontSize: 12,
                            ),
                          ),

                          Text(
                            name,
                            style: const TextStyle(
                              fontSize: 18,
                              fontWeight: FontWeight.bold,
                              color: gold,
                            ),
                          ),

                          Text(
                            gym,
                            style: const TextStyle(
                              color: Colors.white54,
                              fontSize: 11,
                            ),
                          ),
                        ],
                      ),
                    ),
                    const Spacer(),
                    /// NOTIFICATION
                    GestureDetector(
                      onTap: () {

                        Navigator.push(
                          context,
                          MaterialPageRoute(
                              builder: (_) =>
                              const AlertsScreen()),
                        );

                      },

                      child: Container(
                        padding: const EdgeInsets.all(10),
                        decoration: BoxDecoration(
                          color: card,
                          borderRadius: BorderRadius.circular(14),
                        ),
                        child: const Icon(
                          Icons.notifications,
                          color: gold,
                        ),
                      ),
                    )
                  ],
                ),
              ),
            ),
          ),

          /// 📊 KPI SECTION
          SliverToBoxAdapter(
            child: Padding(
              padding:
              const EdgeInsets.all(16),
              child: Row(
                children: const [
                  Expanded(
                      child: KpiCard(
                          "Members",
                          "120",
                          Icons.group)),
                  SizedBox(width: 12),
                  Expanded(
                      child: KpiCard(
                          "Revenue",
                          "₹35K",
                          Icons.currency_rupee)),
                ],
              ),
            ),
          ),

          SliverToBoxAdapter(
            child: Padding(
              padding:
              const EdgeInsets.symmetric(
                  horizontal: 16),
              child: Row(
                children: const [
                  Expanded(
                      child: KpiCard(
                          "Attendance",
                          "98%",
                          Icons.bar_chart)),
                  SizedBox(width: 12),
                  Expanded(
                      child: KpiCard(
                          "Dues",
                          "₹8K",
                          Icons.warning)),
                ],
              ),
            ),
          ),

          /// ⚡ QUICK LINKS
          SliverToBoxAdapter(
            child: Padding(
              padding:
              const EdgeInsets.all(16),
              child: Container(
                padding:
                const EdgeInsets.all(18),
                decoration: BoxDecoration(
                  color: card,
                  borderRadius:
                  BorderRadius.circular(
                      22),
                  boxShadow: [
                    BoxShadow(
                      color: gold.withOpacity(
                          0.08),
                      blurRadius: 20,
                    )
                  ],
                ),

                child: Column(
                  crossAxisAlignment:
                  CrossAxisAlignment.start,
                  children: [

                    const Text(
                      "Quick Links",
                      style: TextStyle(
                        fontSize: 16,
                        fontWeight:
                        FontWeight.bold,
                        color: gold,
                      ),
                    ),

                    const SizedBox(height: 18),

                    GridView.count(
                      crossAxisCount: 4,
                      shrinkWrap: true,
                      physics:
                      const NeverScrollableScrollPhysics(),
                      crossAxisSpacing: 12,
                      mainAxisSpacing: 16,
                      children: const [

                        QuickLinkItem(
                          icon: Icons.people,
                          title: "Members",
                          page: MembersScreen(),
                        ),

                        QuickLinkItem(
                          icon: Icons.workspace_premium,
                          title: "Plans",
                          page: PackagesScreen(),
                        ),

                        QuickLinkItem(
                          icon: Icons.payments,
                          title: "Payments",
                          page: PaymentsScreen(),
                        ),

                        QuickLinkItem(
                          icon: Icons.video_library,
                          title: "Videos",
                          page: VideosScreen(),
                        ),
                      ],
                    ),
                  ],
                ),
              ),
            ),
          ),

          /// 📅 TODAY SCHEDULE
          SliverToBoxAdapter(
            child: _sectionCard(
              title: "Today’s Schedule",
              child: Column(
                children: const [
                  PremiumScheduleTile(
                      "Weight Training",
                      "06:00 AM - 07:00 AM"),
                  PremiumScheduleTile(
                      "Crossfit",
                      "07:00 AM - 08:00 AM"),
                ],
              ),
            ),
          ),

          /// 🔔 RENEWAL ALERTS
          SliverToBoxAdapter(
            child: _sectionCard(
              title: "Renewal Alerts",
              child: const Column(
                children: [
                  RenewalTile(
                    name: "Rahul",
                    daysLeft: "2 days left",
                  ),
                ],
              ),
            ),
          ),

          const SliverToBoxAdapter(
              child: SizedBox(height: 100))
        ],
      ),
    );
  }

  /// SECTION CARD
  static Widget _sectionCard({
    required String title,
    required Widget child,
  }) {

    return Container(
      margin: const EdgeInsets.symmetric(
          horizontal: 16,
          vertical: 10),

      padding: const EdgeInsets.all(18),

      decoration: BoxDecoration(
        color: card,
        borderRadius:
        BorderRadius.circular(22),
      ),

      child: Column(
        crossAxisAlignment:
        CrossAxisAlignment.start,

        children: [

          Text(
            title,
            style: const TextStyle(
                fontSize: 16,
                fontWeight: FontWeight.bold,
                color: gold),
          ),

          const SizedBox(height: 16),

          child
        ],
      ),
    );
  }
}

class KpiCard extends StatelessWidget {
  final String title, value;
  final IconData icon;

  const KpiCard(this.title, this.value, this.icon,
      {super.key});

  @override
  Widget build(BuildContext context) {
    return Container(
      padding: const EdgeInsets.all(18),
      decoration: BoxDecoration(
        color: card,
        borderRadius: BorderRadius.circular(20),
        boxShadow: [
          BoxShadow(
              color: gold.withOpacity(0.08),
              blurRadius: 20)
        ],
      ),
      child: Column(
        children: [
          Icon(icon, color: gold),
          const SizedBox(height: 10),
          Text(value,
              style: const TextStyle(
                  fontSize: 20,
                  fontWeight: FontWeight.bold,
                  color: gold)),
          Text(title,
              style: const TextStyle(
                  color: Colors.white54,
                  fontSize: 12))
        ],
      ),
    );
  }
}

class ActionIcon extends StatelessWidget {
  final IconData icon;
  final String title;

  const ActionIcon(this.icon, this.title,
      {super.key});

  @override
  Widget build(BuildContext context) {
    return GestureDetector(
      onTap: () {
        Navigator.pushReplacement(
          context,
          MaterialPageRoute(
              builder: (_) => const HomePage()),
        );
      },
      child: Column(
        children: [
          Container(
            height: 48,
            width: 48,
            decoration: BoxDecoration(
              color: card,
              borderRadius:
              BorderRadius.circular(14),
            ),
            child: Icon(icon, color: gold),
          ),
          const SizedBox(height: 8),
          Text(title,
              style: const TextStyle(
                  fontSize: 11,
                  color: Colors.white70))
        ],
      ),
    );
  }
}

class PremiumScheduleTile extends StatelessWidget {
  final String title, time;

  const PremiumScheduleTile(
      this.title, this.time,
      {super.key});

  @override
  Widget build(BuildContext context) {
    return Container(
      margin: const EdgeInsets.only(bottom: 14),
      padding: const EdgeInsets.all(16),
      decoration: BoxDecoration(
        gradient: LinearGradient(
          colors: [
            gold.withOpacity(0.08),
            card,
          ],
        ),
        borderRadius: BorderRadius.circular(18),
        border: Border.all(
            color: gold.withOpacity(0.15)),
      ),
      child: Row(
        children: [

          Container(
            height: 44,
            width: 44,
            decoration: BoxDecoration(
              color: gold.withOpacity(0.15),
              shape: BoxShape.circle,
            ),
            child: const Icon(
                Icons.fitness_center,
                color: gold),
          ),

          const SizedBox(width: 14),

          Expanded(
            child: Column(
              crossAxisAlignment:
              CrossAxisAlignment.start,
              children: [
                Text(title,
                    style: const TextStyle(
                        fontWeight:
                        FontWeight.w600)),
                const SizedBox(height: 4),
                Text(time,
                    style: const TextStyle(
                        fontSize: 12,
                        color:
                        Colors.white54)),
              ],
            ),
          ),

          const Icon(Icons.arrow_forward_ios,
              size: 14, color: gold)
        ],
      ),
    );
  }
}

class RenewalTile extends StatelessWidget {
  final String name;
  final String daysLeft;

  const RenewalTile({
    required this.name,
    required this.daysLeft,
    super.key,
  });

  @override
  Widget build(BuildContext context) {
    return Container(
      margin: const EdgeInsets.only(bottom: 14),
      padding: const EdgeInsets.all(16),
      decoration: BoxDecoration(
        color: card,
        borderRadius: BorderRadius.circular(18),
        border: Border.all(
            color: Colors.red.withOpacity(0.3)),
      ),
      child: Row(
        children: [

          const CircleAvatar(
            backgroundColor: Colors.redAccent,
            child: Icon(Icons.warning,
                color: Colors.white),
          ),

          const SizedBox(width: 14),

          Expanded(
            child: Text(name,
                style: const TextStyle(
                    fontWeight:
                    FontWeight.w600)),
          ),

          Container(
            padding: const EdgeInsets.symmetric(
                horizontal: 12, vertical: 6),
            decoration: BoxDecoration(
              color:
              Colors.red.withOpacity(0.15),
              borderRadius:
              BorderRadius.circular(20),
            ),
            child: Text(daysLeft,
                style: const TextStyle(
                    color: Colors.redAccent,
                    fontSize: 11,
                    fontWeight:
                    FontWeight.bold)),
          )
        ],
      ),
    );
  }
}

class QuickLinkItem extends StatelessWidget {
  final IconData icon;
  final String title;
  final Widget page;

  const QuickLinkItem({
    required this.icon,
    required this.title,
    required this.page,
    super.key,
  });

  @override
  Widget build(BuildContext context) {
    return GestureDetector(
      onTap: () {
        Navigator.push(
          context,
          MaterialPageRoute(builder: (_) => page),
        );
      },
      child: Column(
        children: [

          Container(
            height: 50,
            width: 50,
            decoration: BoxDecoration(
              color: gold.withOpacity(0.12),
              borderRadius: BorderRadius.circular(16),
            ),
            child: Icon(icon, color: gold),
          ),

          const SizedBox(height: 8),

          Text(
            title,
            textAlign: TextAlign.center,
            style: const TextStyle(
              fontSize: 11,
              color: Colors.white70,
            ),
          ),
        ],
      ),
    );
  }
}