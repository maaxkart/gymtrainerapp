import 'dart:ui';
import 'package:flutter/material.dart';
import '../../services/api_service.dart';
import '../auth/login_screen.dart';

const gold = Color(0xffFFB300);

class GymRegistrationScreen extends StatefulWidget {
  final List selectedFacilities;
  final String address;

  const GymRegistrationScreen({
    super.key,
    required this.selectedFacilities,
    required this.address,
  });

  @override
  State<GymRegistrationScreen> createState() =>
      _GymRegistrationScreenState();
}

class _GymRegistrationScreenState
    extends State<GymRegistrationScreen>
    with SingleTickerProviderStateMixin {

  final _formKey = GlobalKey<FormState>();

  final gymNameController = TextEditingController();
  final ownerController = TextEditingController();
  final emailController = TextEditingController();
  final mobileController = TextEditingController();
  final locationController = TextEditingController();
  final taxIdController = TextEditingController();
  final passwordController = TextEditingController();
  final confirmPasswordController = TextEditingController();

  bool isSubmitting = false;
  bool obscurePassword = true;
  bool obscureConfirmPassword = true;

  late AnimationController _bgController;

  @override
  void initState() {
    super.initState();

    _bgController = AnimationController(
      vsync: this,
      duration: const Duration(seconds: 8),
    )..repeat();

    /// Auto fill GPS address
    locationController.text = widget.address;
  }

  @override
  void dispose() {

    _bgController.dispose();

    gymNameController.dispose();
    ownerController.dispose();
    emailController.dispose();
    mobileController.dispose();
    locationController.dispose();
    taxIdController.dispose();
    passwordController.dispose();
    confirmPasswordController.dispose();

    super.dispose();
  }

  Future<void> submit() async {

    if (!_formKey.currentState!.validate()) return;

    setState(() => isSubmitting = true);

    try {

      final response = await ApiService.registerGym(
        gymName: gymNameController.text,
        address: locationController.text,
        taxId: taxIdController.text,
        facilities: widget.selectedFacilities,
        name: ownerController.text,
        email: emailController.text,
        password: passwordController.text,
        passwordConfirmation: confirmPasswordController.text,
      );

      setState(() => isSubmitting = false);

      if (response["status"] == "success") {

        ScaffoldMessenger.of(context).showSnackBar(
          const SnackBar(
            content: Text("Gym Registered Successfully"),
            backgroundColor: gold,
          ),
        );

        Navigator.pushReplacement(
          context,
          MaterialPageRoute(
            builder: (_) => const LoginScreen(),
          ),
        );

      } else {

        final errors = response["errors"];

        ScaffoldMessenger.of(context).showSnackBar(
          SnackBar(
            content: Text(errors.toString()),
            backgroundColor: Colors.red,
          ),
        );
      }

    } catch (e) {

      setState(() => isSubmitting = false);

      ScaffoldMessenger.of(context).showSnackBar(
        const SnackBar(
          content: Text("Server Error"),
          backgroundColor: Colors.red,
        ),
      );
    }
  }

  @override
  Widget build(BuildContext context) {

    return Scaffold(
      body: Stack(
        children: [

          /// Background animation
          AnimatedBuilder(
            animation: _bgController,
            builder: (context, _) {
              return Container(
                decoration: BoxDecoration(
                  gradient: LinearGradient(
                    colors: const [
                      Color(0xff0B0D12),
                      Color(0xff141821),
                      Color(0xff1C1F2A),
                    ],
                    begin: Alignment.topLeft,
                    end: Alignment.bottomRight,
                    stops: [0.0, _bgController.value, 1.0],
                  ),
                ),
              );
            },
          ),

          /// Main content
          SafeArea(
            child: SingleChildScrollView(
              physics: const BouncingScrollPhysics(),
              padding: const EdgeInsets.all(24),

              child: Column(
                crossAxisAlignment: CrossAxisAlignment.start,
                children: [

                  const SizedBox(height: 30),

                  const Text(
                    "Register Your Gym",
                    style: TextStyle(
                      color: Colors.white,
                      fontSize: 30,
                      fontWeight: FontWeight.bold,
                    ),
                  ),

                  const SizedBox(height: 40),

                  ClipRRect(
                    borderRadius: BorderRadius.circular(30),

                    child: BackdropFilter(
                      filter: ImageFilter.blur(
                        sigmaX: 20,
                        sigmaY: 20,
                      ),

                      child: Container(
                        padding: const EdgeInsets.all(25),

                        decoration: BoxDecoration(
                          color: Colors.white.withOpacity(0.05),
                          borderRadius: BorderRadius.circular(30),
                        ),

                        child: Form(
                          key: _formKey,

                          child: Column(
                            children: [

                              buildField(
                                "Gym Name",
                                Icons.fitness_center,
                                gymNameController,
                              ),

                              const SizedBox(height: 20),

                              buildField(
                                "Owner Name",
                                Icons.person,
                                ownerController,
                              ),

                              const SizedBox(height: 20),

                              buildField(
                                "Email",
                                Icons.email,
                                emailController,
                                type: TextInputType.emailAddress,
                              ),

                              const SizedBox(height: 20),

                              buildField(
                                "Mobile",
                                Icons.phone,
                                mobileController,
                                type: TextInputType.phone,
                              ),

                              const SizedBox(height: 20),

                              buildField(
                                "Tax ID",
                                Icons.badge,
                                taxIdController,
                              ),

                              const SizedBox(height: 20),

                              buildPasswordField(),

                              const SizedBox(height: 20),

                              buildConfirmPasswordField(),

                              const SizedBox(height: 20),

                              buildField(
                                "Address",
                                Icons.location_on,
                                locationController,
                              ),

                              const SizedBox(height: 35),

                              GestureDetector(
                                onTap: isSubmitting ? null : submit,

                                child: AnimatedContainer(
                                  duration: const Duration(milliseconds: 300),
                                  height: 60,

                                  decoration: BoxDecoration(
                                    borderRadius: BorderRadius.circular(20),

                                    gradient: const LinearGradient(
                                      colors: [
                                        Color(0xffFFB300),
                                        Color(0xffFF8F00),
                                      ],
                                    ),
                                  ),

                                  child: Center(
                                    child: isSubmitting
                                        ? const CircularProgressIndicator(
                                      color: Colors.black,
                                    )
                                        : const Text(
                                      "Register Gym",
                                      style: TextStyle(
                                        fontSize: 17,
                                        fontWeight: FontWeight.bold,
                                        color: Colors.black,
                                      ),
                                    ),
                                  ),
                                ),
                              ),
                            ],
                          ),
                        ),
                      ),
                    ),
                  ),
                ],
              ),
            ),
          )
        ],
      ),
    );
  }

  Widget buildField(
      String hint,
      IconData icon,
      TextEditingController controller, {
        TextInputType type = TextInputType.text,
      }) {
    return TextFormField(
      controller: controller,
      keyboardType: type,
      style: const TextStyle(color: Colors.white),
      validator: (value) =>
      value!.isEmpty ? "Required Field" : null,
      decoration: InputDecoration(
        prefixIcon: Icon(icon, color: gold),
        hintText: hint,
        hintStyle: const TextStyle(color: Colors.white38),
        filled: true,
        fillColor: Colors.black.withOpacity(0.4),
        border: OutlineInputBorder(
          borderRadius: BorderRadius.circular(18),
          borderSide: BorderSide.none,
        ),
      ),
    );
  }

  Widget buildPasswordField() {
    return TextFormField(
      controller: passwordController,
      obscureText: obscurePassword,
      style: const TextStyle(color: Colors.white),
      validator: (value) {
        if (value == null || value.isEmpty) {
          return "Password required";
        }
        if (value.length < 6) {
          return "Minimum 6 characters required";
        }
        return null;
      },
      decoration: InputDecoration(
        prefixIcon: const Icon(Icons.lock, color: gold),
        suffixIcon: IconButton(
          icon: Icon(
            obscurePassword
                ? Icons.visibility_off
                : Icons.visibility,
            color: gold,
          ),
          onPressed: () {
            setState(() {
              obscurePassword = !obscurePassword;
            });
          },
        ),
        hintText: "Password",
        filled: true,
        fillColor: Colors.black.withOpacity(0.4),
        border: OutlineInputBorder(
          borderRadius: BorderRadius.circular(18),
          borderSide: BorderSide.none,
        ),
      ),
    );
  }

  Widget buildConfirmPasswordField() {
    return TextFormField(
      controller: confirmPasswordController,
      obscureText: obscureConfirmPassword,
      style: const TextStyle(color: Colors.white),
      validator: (value) {
        if (value != passwordController.text) {
          return "Passwords do not match";
        }
        return null;
      },
      decoration: InputDecoration(
        prefixIcon: const Icon(Icons.lock_outline, color: gold),
        suffixIcon: IconButton(
          icon: Icon(
            obscureConfirmPassword
                ? Icons.visibility_off
                : Icons.visibility,
            color: gold,
          ),
          onPressed: () {
            setState(() {
              obscureConfirmPassword =
              !obscureConfirmPassword;
            });
          },
        ),
        hintText: "Confirm Password",
        filled: true,
        fillColor: Colors.black.withOpacity(0.4),
        border: OutlineInputBorder(
          borderRadius: BorderRadius.circular(18),
          borderSide: BorderSide.none,
        ),
      ),
    );
  }
}