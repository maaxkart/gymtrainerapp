import 'dart:ui';
import 'package:flutter/material.dart';
import '../../services/api_service.dart';
import '../../shared/widgets/premium_card.dart';
import '../members/add_member_screen.dart';

const gold = Color(0xffFFB300);
const bg = Color(0xff0F1115);
const card = Color(0xff1A1D24);

class MembersScreen extends StatefulWidget {
  const MembersScreen({super.key});

  @override
  State<MembersScreen> createState() => _MembersScreenState();
}

class _MembersScreenState extends State<MembersScreen> {

  List members = [];
  bool loading = true;

  @override
  void initState() {
    super.initState();
    loadMembers();
  }

  Future loadMembers() async {

    try {

      final data = await ApiService.getMembers();

      setState(() {
        members = data;
        loading = false;
      });

    } catch (e) {

      setState(() {
        loading = false;
      });
    }
  }

  @override
  Widget build(BuildContext context) {

    return Scaffold(
      backgroundColor: bg,

      /// FAB
      floatingActionButtonLocation: FloatingActionButtonLocation.centerFloat,

      floatingActionButton: Container(
        decoration: BoxDecoration(
          borderRadius: BorderRadius.circular(30),
          boxShadow: [
            BoxShadow(
              color: gold.withOpacity(0.5),
              blurRadius: 25,
            )
          ],
        ),
        child: FloatingActionButton.extended(
          backgroundColor: gold,

          onPressed: () {

            Navigator.push(
              context,
              MaterialPageRoute(
                builder: (_) => const AddMemberScreen(),
              ),
            );
          },

          icon: const Icon(Icons.person_add, color: Colors.black),

          label: const Text(
            "Add Member",
            style: TextStyle(
              color: Colors.black,
              fontWeight: FontWeight.bold,
            ),
          ),
        ),
      ),

      /// APPBAR
      appBar: PreferredSize(
        preferredSize: const Size.fromHeight(70),
        child: ClipRRect(
          child: BackdropFilter(
            filter: ImageFilter.blur(sigmaX: 10, sigmaY: 10),

            child: AppBar(
              title: const Text("Members"),
              backgroundColor: Colors.black.withOpacity(0.3),
              elevation: 0,

              actions: const [
                Icon(Icons.tune, color: gold),
                SizedBox(width: 16)
              ],
            ),
          ),
        ),
      ),

      body: Column(
        children: [

          /// SEARCH
          Padding(
            padding: const EdgeInsets.all(16),

            child: TextField(
              decoration: InputDecoration(
                hintText: "Search members...",
                prefixIcon: const Icon(Icons.search, color: gold),
                filled: true,
                fillColor: card,

                border: OutlineInputBorder(
                  borderRadius: BorderRadius.circular(20),
                  borderSide: BorderSide.none,
                ),
              ),
            ),
          ),

          /// KPI
          SizedBox(
            height: 100,

            child: Row(
              mainAxisAlignment: MainAxisAlignment.center,

              children: [
                UltraKpiCard("Members", members.length.toString(), Icons.group),
                const UltraKpiCard("Active", "0", Icons.check_circle),
                const UltraKpiCard("Revenue", "₹0", Icons.currency_rupee),
              ],
            ),
          ),

          const SizedBox(height: 10),

          const PremiumSegment(),

          /// MEMBER LIST
          Expanded(

            child: loading
                ? const Center(child: CircularProgressIndicator(color: gold))

                : ListView.builder(

              padding: const EdgeInsets.only(bottom: 100),

              itemCount: members.length,

              itemBuilder: (_, i) {

                final member = members[i];

                return UltraMemberCard(
                  name: member["name"] ?? "",
                  joinDate: member["join_date"] ?? "",
                  expiry: member["expiry_date"] ?? "",
                  attendance: member["attendance"] ?? 0,
                  plan: member["plan"] ?? "Basic",
                  paid: member["paid"] ?? false,
                );
              },
            ),
          )
        ],
      ),
    );
  }
}

class UltraKpiCard extends StatelessWidget {

  final String title;
  final String value;
  final IconData icon;

  const UltraKpiCard(this.title, this.value, this.icon, {super.key});

  @override
  Widget build(BuildContext context) {

    return Container(
      width: 120,
      margin: const EdgeInsets.only(right: 12),

      padding: const EdgeInsets.symmetric(horizontal: 10, vertical: 8),

      decoration: BoxDecoration(
        color: card,
        borderRadius: BorderRadius.circular(16),
        border: const Border(
          top: BorderSide(color: gold, width: 2),
        ),
      ),

      child: Column(
        mainAxisSize: MainAxisSize.min,
        children: [

          Container(
            padding: const EdgeInsets.all(4),
            decoration: BoxDecoration(
              color: gold.withOpacity(0.15),
              shape: BoxShape.circle,
            ),

            child: Icon(icon, size: 12, color: gold),
          ),

          const SizedBox(height: 6),

          Text(
            value,
            style: const TextStyle(
                fontSize: 14,
                fontWeight: FontWeight.bold,
                color: gold),
          ),

          Text(
            title,
            style: const TextStyle(
                fontSize: 9,
                color: Colors.white54),
          ),
        ],
      ),
    );
  }
}

class PremiumSegment extends StatelessWidget {
  const PremiumSegment({super.key});

  @override
  Widget build(BuildContext context) {

    return Container(
      margin: const EdgeInsets.symmetric(horizontal: 16),
      padding: const EdgeInsets.all(4),

      decoration: BoxDecoration(
        color: card,
        borderRadius: BorderRadius.circular(30),
      ),

      child: Row(
        children: const [
          Expanded(child: SegmentItem("All", true)),
          Expanded(child: SegmentItem("Active", false)),
          Expanded(child: SegmentItem("Expired", false)),
        ],
      ),
    );
  }
}

class SegmentItem extends StatelessWidget {

  final String text;
  final bool active;

  const SegmentItem(this.text, this.active, {super.key});

  @override
  Widget build(BuildContext context) {

    return Container(
      padding: const EdgeInsets.symmetric(vertical: 10),

      decoration: BoxDecoration(
        color: active ? gold : Colors.transparent,
        borderRadius: BorderRadius.circular(30),
      ),

      child: Center(
        child: Text(
          text,
          style: TextStyle(
              color: active ? Colors.black : Colors.white),
        ),
      ),
    );
  }
}

class UltraMemberCard extends StatelessWidget {

  final String name;
  final String joinDate;
  final String expiry;
  final double attendance;
  final String plan;
  final bool paid;

  const UltraMemberCard({
    super.key,
    required this.name,
    required this.joinDate,
    required this.expiry,
    required this.attendance,
    required this.plan,
    required this.paid,
  });

  @override
  Widget build(BuildContext context) {

    return Container(
      margin: const EdgeInsets.symmetric(horizontal: 16, vertical: 8),

      decoration: BoxDecoration(
        borderRadius: BorderRadius.circular(22),
        border: Border.all(color: gold.withOpacity(0.15)),
      ),

      child: PremiumCard(
        child: Row(
          children: [

            const CircleAvatar(
              radius: 22,
              backgroundColor: Color(0xff1E212A),
              child: Icon(Icons.person, color: Colors.white70),
            ),

            const SizedBox(width: 14),

            Expanded(
              child: Column(
                crossAxisAlignment: CrossAxisAlignment.start,
                children: [

                  Text(
                    name,
                    style: const TextStyle(
                        fontWeight: FontWeight.bold,
                        fontSize: 15),
                  ),

                  const SizedBox(height: 6),

                  Text(
                    "Joined $joinDate • Exp $expiry",
                    style: const TextStyle(
                        color: Colors.white54,
                        fontSize: 12),
                  ),
                ],
              ),
            ),

            Text(
              "${attendance.toInt()}%",
              style: const TextStyle(color: gold),
            ),

            const SizedBox(width: 10),

            Icon(
              paid ? Icons.check_circle : Icons.error,
              color: paid ? Colors.green : Colors.red,
              size: 18,
            ),

            const SizedBox(width: 10),
          ],
        ),
      ),
    );
  }
}