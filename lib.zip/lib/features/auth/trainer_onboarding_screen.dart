import 'dart:ui';
import 'package:flutter/material.dart';
import '../../services/api_service.dart';
import '../gymregistration/register.dart';

const gold = Color(0xffFFB300);
const bg = Color(0xff0B0D12);
const card = Color(0xff12141A);

class TrainerOnboardingScreen extends StatefulWidget {

  final String address;

  const TrainerOnboardingScreen({
    super.key,
    required this.address,
  });

  @override
  State<TrainerOnboardingScreen> createState() =>
      _TrainerOnboardingScreenState();
}

class _TrainerOnboardingScreenState
    extends State<TrainerOnboardingScreen> {

  final PageController _controller = PageController();

  int page = 0;

  /// facilities from API
  List<Map<String, dynamic>> facilities = [];

  bool loading = true;

  /// selected facility names
  List<String> selectedFacilities = [];

  /// selected questions
  List<String> selectedQuestions = [];

  @override
  void initState() {
    super.initState();
    loadFacilities();
  }

  /// LOAD FACILITIES FROM API
  Future<void> loadFacilities() async {

    try {

      final data = await ApiService.getFacilities();

      setState(() {
        facilities = List<Map<String, dynamic>>.from(data);
        loading = false;
      });

    } catch (e) {

      print("Facility API Error: $e");

      setState(() {
        loading = false;
      });
    }
  }

  /// NEXT PAGE
  void nextPage() {

    if (page == facilities.length - 1) {

      /// prevent empty facilities
      if (selectedFacilities.isEmpty) {

        ScaffoldMessenger.of(context).showSnackBar(
          const SnackBar(
            content: Text("Please select at least one facility"),
          ),
        );

        return;
      }

      print("FINAL FACILITIES: $selectedFacilities");

      Navigator.pushReplacement(
        context,
        MaterialPageRoute(
          builder: (_) => GymRegistrationScreen(
            selectedFacilities: selectedFacilities,
            address: widget.address,
          ),
        ),
      );

    } else {

      _controller.nextPage(
        duration: const Duration(milliseconds: 500),
        curve: Curves.easeInOut,
      );
    }
  }

  @override
  Widget build(BuildContext context) {

    return Scaffold(
      backgroundColor: bg,
      bottomNavigationBar: _bottomButton(),
      body: loading
          ? const Center(
          child: CircularProgressIndicator(color: gold))
          : Stack(
        children: [

          /// PAGE VIEW
          PageView(
            controller: _controller,
            onPageChanged: (i) {
              setState(() => page = i);
            },
            children: facilities.map((facility) {

              return _buildPage(
                image:
                "https://images.unsplash.com/photo-1571902943202-507ec2618e8f",
                title: facility["name"],
                subtitle: facility["category"],
                facilityName: facility["name"],
                questions:
                List<String>.from(facility["questions"]),
              );

            }).toList(),
          ),

          /// STEP INDICATOR
          Positioned(
            top: 60,
            left: 0,
            right: 0,
            child: Row(
              mainAxisAlignment: MainAxisAlignment.center,
              children: List.generate(
                facilities.length,
                    (i) => AnimatedContainer(
                  duration:
                  const Duration(milliseconds: 300),
                  margin: const EdgeInsets.symmetric(
                      horizontal: 4),
                  height: 6,
                  width: page == i ? 28 : 10,
                  decoration: BoxDecoration(
                    color: page == i
                        ? gold
                        : Colors.white24,
                    borderRadius:
                    BorderRadius.circular(20),
                  ),
                ),
              ),
            ),
          )
        ],
      ),
    );
  }

  /// PAGE UI
  Widget _buildPage({
    required String image,
    required String title,
    required String subtitle,
    required String facilityName,
    required List<String> questions,
  }) {

    return Stack(
      fit: StackFit.expand,
      children: [

        Image.network(image, fit: BoxFit.cover),

        Container(
          decoration: BoxDecoration(
            gradient: LinearGradient(
              colors: [
                Colors.black.withOpacity(0.85),
                Colors.black.withOpacity(0.6),
                Colors.black.withOpacity(0.9),
              ],
              begin: Alignment.topCenter,
              end: Alignment.bottomCenter,
            ),
          ),
        ),

        SafeArea(
          child: Column(
            children: [

              /// SKIP
              Align(
                alignment: Alignment.topRight,
                child: TextButton(
                  onPressed: nextPage,
                  child: const Text(
                    "Skip",
                    style: TextStyle(color: gold),
                  ),
                ),
              ),

              const Spacer(),

              /// CARD
              Container(
                margin: const EdgeInsets.all(16),
                padding: const EdgeInsets.all(24),
                decoration: BoxDecoration(
                  borderRadius: BorderRadius.circular(28),
                  color: card.withOpacity(0.9),
                  border: Border.all(color: Colors.white10),
                  boxShadow: [
                    BoxShadow(
                      color: gold.withOpacity(0.15),
                      blurRadius: 30,
                      spreadRadius: -10,
                    )
                  ],
                ),

                child: Column(
                  crossAxisAlignment:
                  CrossAxisAlignment.start,
                  mainAxisSize: MainAxisSize.min,
                  children: [

                    /// TITLE
                    Text(
                      title,
                      style: const TextStyle(
                        fontSize: 24,
                        fontWeight: FontWeight.bold,
                      ),
                    ),

                    const SizedBox(height: 6),

                    /// CATEGORY
                    Text(
                      subtitle,
                      style: const TextStyle(
                        color: Colors.white54,
                        fontSize: 13,
                      ),
                    ),

                    const SizedBox(height: 22),

                    /// QUESTIONS
                    Wrap(
                      spacing: 10,
                      runSpacing: 10,
                      children: questions
                          .map((q) =>
                          _chip(q, facilityName))
                          .toList(),
                    ),
                  ],
                ),
              ),
            ],
          ),
        )
      ],
    );
  }

  /// CHIP
  Widget _chip(String text, String facilityName) {

    final isSelected =
    selectedQuestions.contains(text);

    return GestureDetector(
      onTap: () {

        setState(() {

          if (isSelected) {

            selectedQuestions.remove(text);

            /// remove facility if no question left
            bool stillSelected = facilities.any((facility) =>
                facility["questions"]
                    .any((q) => selectedQuestions.contains(q)));

            if (!stillSelected) {
              selectedFacilities.remove(facilityName);
            }

          } else {

            selectedQuestions.add(text);

            if (!selectedFacilities
                .contains(facilityName)) {

              selectedFacilities.add(facilityName);
            }
          }
        });

        print("Selected Facilities: $selectedFacilities");
      },

      child: AnimatedContainer(
        duration: const Duration(milliseconds: 250),
        padding: const EdgeInsets.symmetric(
            horizontal: 18, vertical: 12),

        decoration: BoxDecoration(
          color: isSelected ? gold : card,
          borderRadius: BorderRadius.circular(30),
        ),

        child: Text(
          text,
          style: TextStyle(
            color: isSelected
                ? Colors.black
                : Colors.white,
          ),
        ),
      ),
    );
  }

  /// BOTTOM BUTTON
  Widget _bottomButton() {

    return Padding(
      padding: const EdgeInsets.all(16),

      child: ElevatedButton(
        style: ElevatedButton.styleFrom(
          backgroundColor: gold,
          padding:
          const EdgeInsets.symmetric(vertical: 16),
          shape: RoundedRectangleBorder(
            borderRadius:
            BorderRadius.circular(14),
          ),
        ),

        onPressed: nextPage,

        child: Text(
          page == facilities.length - 1
              ? "Finish"
              : "Continue",

          style: const TextStyle(
            color: Colors.black,
            fontWeight: FontWeight.bold,
          ),
        ),
      ),
    );
  }
}