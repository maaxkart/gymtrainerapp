import 'package:flutter/material.dart';

const gold = Color(0xffFFB300);
const bg = Color(0xff0B0D12);
const card = Color(0xff12141A);

class AlertsScreen extends StatelessWidget {
  const AlertsScreen({super.key});

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      backgroundColor: bg,
      appBar: AppBar(
        backgroundColor: bg,
        elevation: 0,
        title: const Text("Alerts"),
      ),
      body: ListView(
        padding: const EdgeInsets.all(16),
        children: const [

          AlertTile(
            title: "Membership Expiring",
            subtitle: "Rahul - 2 days left",
          ),

          AlertTile(
            title: "Payment Due",
            subtitle: "Arjun - ₹2000 pending",
          ),

        ],
      ),
    );
  }
}

class AlertTile extends StatelessWidget {
  final String title;
  final String subtitle;

  const AlertTile({
    required this.title,
    required this.subtitle,
    super.key,
  });

  @override
  Widget build(BuildContext context) {
    return Container(
      margin: const EdgeInsets.only(bottom: 14),
      padding: const EdgeInsets.all(16),
      decoration: BoxDecoration(
        color: card,
        borderRadius: BorderRadius.circular(18),
        border: Border.all(
          color: Colors.red.withOpacity(0.3),
        ),
      ),
      child: Row(
        children: [

          const CircleAvatar(
            backgroundColor: Colors.redAccent,
            child: Icon(Icons.warning,
                color: Colors.white),
          ),

          const SizedBox(width: 14),

          Expanded(
            child: Column(
              crossAxisAlignment:
              CrossAxisAlignment.start,
              children: [
                Text(title,
                    style: const TextStyle(
                        fontWeight:
                        FontWeight.bold)),
                const SizedBox(height: 4),
                Text(subtitle,
                    style: const TextStyle(
                        fontSize: 12,
                        color:
                        Colors.white54)),
              ],
            ),
          ),
        ],
      ),
    );
  }
}