import 'package:flutter/material.dart';
import 'core/theme/app_theme.dart';
import 'features/auth/login_screen.dart';

import 'features/gymregistration/register.dart';
import 'core/constants/locationfetch.dart';
import 'features/auth/trainer_onboarding_screen.dart';
import 'features/dashboard/main_navigation_screen.dart';

void main() {
  runApp(const TrainerApp());
}

class TrainerApp extends StatelessWidget {
  const TrainerApp({super.key});

  @override
  Widget build(BuildContext context) {
    return MaterialApp(
      debugShowCheckedModeBanner: false,
      theme: AppTheme.dark,
     //home: const LocationDetectScreen(),
      home: const LoginScreen(),
      //home: const MainNavigationScreen(),
    );
  }
}